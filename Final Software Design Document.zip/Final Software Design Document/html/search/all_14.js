var searchData=
[
  ['xtextfield_0',['xTextField',['../classedu_1_1wright_1_1airviewer2_1_1_annotation_dialog.html#a102a2b73f3243cc01ae3fb4c668edc83',1,'edu.wright.airviewer2.AnnotationDialog.xTextField()'],['../classedu_1_1wright_1_1airviewer2_1_1_image_annotation_dialog.html#a849ef0e32be9ddcaa16295a66e9fe797',1,'edu.wright.airviewer2.ImageAnnotationDialog.xTextField()']]]
];
