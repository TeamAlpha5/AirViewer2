var searchData=
[
  ['watermarkadd_0',['watermarkAdd',['../classedu_1_1wright_1_1airviewer2_1_1_watermarkaddition.html#ad10225f10858a1ecd6d37ffe7723022d',1,'edu::wright::airviewer2::Watermarkaddition']]],
  ['watermarkaddition_1',['Watermarkaddition',['../classedu_1_1wright_1_1airviewer2_1_1_watermarkaddition.html#a1542a2121a344a8508c339d967d2ea74',1,'edu::wright::airviewer2::Watermarkaddition']]]
];
