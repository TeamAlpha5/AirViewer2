var searchData=
[
  ['footeraddition_0',['footerAddition',['../classedu_1_1wright_1_1airviewer2_1_1_footer_addition.html#a7ff1f06d7199bcbe5787f694b66e89e0',1,'edu::wright::airviewer2::FooterAddition']]],
  ['footeraddition_1',['FooterAddition',['../classedu_1_1wright_1_1airviewer2_1_1_footer_addition.html#a244cd4bdc95e10d0bcd8db916273c1dc',1,'edu::wright::airviewer2::FooterAddition']]]
];
