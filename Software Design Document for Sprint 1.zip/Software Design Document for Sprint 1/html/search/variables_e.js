var searchData=
[
  ['undoname_0',['undoName',['../classedu_1_1wright_1_1airviewer2_1_1_abstract_document_command_wrapper_1_1_abstract_document_command.html#a26fa05959551583b8ab953307e0eeae5',1,'edu::wright::airviewer2::AbstractDocumentCommandWrapper::AbstractDocumentCommand']]],
  ['undostack_1',['undoStack',['../classedu_1_1wright_1_1airviewer2_1_1_abstract_document_command_wrapper.html#a80374821190ff027965433a4d6893e0b',1,'edu::wright::airviewer2::AbstractDocumentCommandWrapper']]]
];
